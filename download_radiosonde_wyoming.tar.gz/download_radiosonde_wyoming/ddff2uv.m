function [u,v] = ddff2uv(dd,ff)
% This function turns speed(ff) and direction(dd) into components(u,v) according to WMO standard
% AUTHOR: Idar Barstad, Bergen Nov '05
% UPDATE-IB22/9-10: error messages for matrix and wrongly pointing vectors 
%
%if size(dd,2) >= 2
if size(dd,1) >= 2
  error('dont use matrices, only vectors works and put them the correct direction')
end

% ff is in knots
u=ff.*sin(dd/180*pi);
v=ff.*cos(dd/180*pi);

v=abs(v);u=abs(u);
for i=1:length(dd)
if dd(i) >= 270 || dd(i) < 90
  v(i) = abs(v(i))*(-1);
end
if dd(i) > 360 || dd(i)< 180
  u(i) = abs(u(i))*(-1);
end
end
