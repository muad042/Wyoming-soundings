function [R11,R12,R13,R14,B11,B12,B13,B14]=error_stats_1(size,pm,var_mod,var_obs,po,R,B)
%B: Bias
%R: RMSE
%S: STDE
%size: size of the array
%pm: model pressure levels
%po: observations pressure levels
%var_mod: model variable
%var_obs: corresponding observed variable

%Estimating RMSE for different layers (50 m) below 2 km
for i=1:size
    clear L M N O Bs1 Bs2 Bs3 Bs4 SE1 Se2 SE3 SE4 MSE1 MSE2 MSE3 MSE4 R1 R2 R3 R4 Rtot Btot
    var_int_MtoO(i,:)=interp1(pm(i,:),var_mod(i,:),po(i,:),'spline');
    [L]=find(po(i,:)<=1000 & po(i,:)>=950);
    [M]=find(po(i,:)<=950 & po(i,:)>=900);
    [N]=find(po(i,:)<=900 & po(i,:)>=850);
    [O]=find(po(i,:)<=850 & po(i,:)>=800);
    B1 = var_int_MtoO(i,L) - var_obs(i,L);SE1 = B1.^2;MSE1 = nanmean(SE1);
    B2 = var_int_MtoO(i,M) - var_obs(i,M);SE2 = B2.^2;MSE2 = nanmean(SE2);
    B3 = var_int_MtoO(i,N) - var_obs(i,N);SE3 = B3.^2;MSE3 = nanmean(SE3);
    B4 = var_int_MtoO(i,O) - var_obs(i,O);SE4 = B4.^2;MSE4 = nanmean(SE4);
    Bs1 = nanmean(B1);Bs2 = nanmean(B2);Bs3 = nanmean(B3);Bs4 = nanmean(B4);
    R1 = sqrt(MSE1); R2 = sqrt(MSE2); R3 = sqrt(MSE3); R4 = sqrt(MSE4);
% Total of RMSE at different layers is not equal to the RMSE computed
% before. So we find the 'R11', 'R12', 'R13' and 'R14' that add up to give the
% exact RMSE for the 2 km layer.
    Btot = nansum(Bs1)+nansum(Bs2)+nansum(Bs3)+nansum(Bs4);
    B11(i) = (B(i)*Bs1)/Btot;
    B12(i) = (B(i)*Bs2)/Btot;
    B13(i) = (B(i)*Bs3)/Btot;
    B14(i) = (B(i)*Bs4)/Btot;
    %test(i) = R(i) - (R11(i)+R12(i)+R13(i)+R14(i));
    Rtot = nansum(R1)+nansum(R2)+nansum(R3)+nansum(R4);
    R11(i) = (R(i)*R1)/Rtot;
    R12(i) = (R(i)*R2)/Rtot;
    R13(i) = (R(i)*R3)/Rtot;
    R14(i) = (R(i)*R4)/Rtot;

end