% This program reads in sonde data which has been retrieved from Univ Wyoming-website
%   The data has been downloaded with ~/data/sonde_from_UWYOM.ksh
%   followed by preparation of ~/data/prepFormatlab.ksh
%   ending with this program read_sondeFromUWY.m
%
%   The filename length is assumed to be sonde_+10 digits, see below.
%
%   AUTHOR: Idar.Barstad@uni.no, Gj�vik, 25 May 2011

clear
%path_data_store=['/scratch/MATLAB/Valentia_03953/'];
%path_data_store=['/scratch/MATLAB/Ekofisk_01400/'];
path_data_store=['/scratch/MATLAB/Lerwick_03005/'];


fro_date =datenum('01.01.2000','dd.mm.yyyy');
to_date  =datenum('31.12.2009','dd.mm.yyyy');


clear s i a b ii yyyy_good
s=dir(path_data_store);
[a b]=size(s); ii=1;

for i=1:a
  if length((s(i).name))==17
  yyyy=s(i).name(13:16);
   if yyyy >= datestr(fro_date,'yyyy') & yyyy <= datestr(to_date,'yyyy') ;
   yyyy_good(ii)={(s(i).name)}; ii=ii+1;
   end
 end
end


% first get the list of files incl. file-path:  

clear good_files ind_len
ii=1;

for i = 1:length(yyyy_good)

 unix([ 'rm -f toto' ]);
 unix([ 'find ' path_data_store char(yyyy_good(i)) '>toto']);
 [fname1]=textread('toto','%s');

 for i=1:length(fname1)
   clear dum_name
   dum_name=char(fname1(i));
  if exist(dum_name)==2 & dum_name(end)=='m'  
   ind_len(ii)=length(char(fname1(i)));
   good_files(ii)=fname1(i);
   ii=ii+1;
  end
 end

end

gf=char(good_files);

% EDIT HERE - filename specific 

   clear date_files

 for i = 1 : length(good_files)
   clear tt 
     tt(i,1:10) = gf(i,(ind_len(i)-10):ind_len(i)-1);                               % the length of date in file name is sonde_+10digits
  date_files(i) = datenum(str2num([tt(i,7:10)]),str2num(tt(i,5:6)),...
                  str2num(tt(i,3:4)),str2num(tt(i,1:2)),0,0 );
 end



%    sorted by time;

[sort_date, ind_sort]=sort(date_files);



% READ in the files found OK:

clear p_all z_all tk_all rh_all wsp_all dd_all


len_rec=1;
p_all(1:length(good_files),1:500)=NaN; z_all(1:length(good_files),1:500)=NaN; tk_all(1:length(good_files),1:500)=NaN;
rh_all(1:length(good_files),1:500)=NaN; wsp_all(1:length(good_files),1:500)=NaN; dd_all(1:length(good_files),1:500)=NaN;

for i=1:length(good_files)

   clear dum1 plev zlev tk rh td wsp dd uvel vvel lon lat dum2 dum3

  sonde_file=char(good_files(ind_sort(i)));                         % get it cronologically

%      p      hgt   tmp    td    rh    r     dd    ff     th    the   thv 
%fmt=['%6.1f %6.0f  %6.1f %6.1f  %6.0f %4.2f %3.0f %3.0f  %4.1f  %4.1f %4.1f\n'];
fmt=['%f %f  %f %f  %f %f %f %f  %f  %f %f '];
[plev zlev tk td rh r dd ff th the thv]=textread(sonde_file,fmt,'headerlines',4);



len_rec=max(len_rec,length(plev));
p_all(i,1:length(plev))=plev; z_all(i,1:length(plev))=zlev; tk_all(i,1:length(plev))=tk; rh_all(i,1:length(plev))=rh; wsp_all(i,1:length(plev))=ff; dd_all(i,1:length(plev))=dd;

end

%clear r rh s td th the thv tk plev to_date fro_date tt tttt yyyy yyyy_good zlev date_files i len_rec 
%clear fmt ff path_data_store sort_date ind_len ii ff fname1 gf a b dd dum_name sonde_file 
%
%   ###########################################################################
%
% ---- The data are ready to go!
%
%
%  ---- Preparatory
%
%   ---  DIMENSIONS -- :

dim_tim = size(z_all,1);
dim_z   = size(z_all,2);
th_all(1:dim_tim,1:dim_z)=NaN;

tk_all=tk_all+273.16;


%  --  calc theta:

for i=1:dim_tim
 [th_all(i,:)] = calc_theta_T(tk_all(i,:),p_all(i,:),'theta_back');
end

for k = 1:dim_tim
  [ichos] = find( z_all(k,:)<8000 & z_all(k,:)>0 );
  if ~isempty(find(th_all(k,ichos)<0))
   disp(['problem with theta',num2str(k)])
  end
end


%    
%    ---  INTERPOLATE ALL VARIABLES to every 50m:
%

% clear tkint thint zint rhint wspint ddint
% zint=[100:50:3000];
% tkint(1:dim_tim,1:length(zint))  = NaN;
% thint(1:dim_tim,1:length(zint))  = NaN;
% rhint(1:dim_tim,1:length(zint))  = NaN;
% pint(1:dim_tim,1:length(zint))   = NaN;
% wspint(1:dim_tim,1:length(zint)) = NaN;
% ddint(1:dim_tim,1:length(zint))  = NaN;
% 
% for i = [{'p', 'tk', 'th', 'rh', 'wsp', 'dd'}]
% 
%  if strcmp('th',char(i))
%    not_def=100;
%  elseif strcmp('rh',char(i))
%    not_def=-0.01;
%  elseif strcmp('wsp',char(i))
%   not_def=-0.1;
%  elseif strcmp('dd',char(i))
%   not_def=-0.1;
%  elseif strcmp('tk',char(i))
%   not_def=-0.1;
%  elseif strcmp('p',char(i))
%   not_def=-0.1;
% 
%  end
% 
%  eval(['dum_all=' char(i) '_all;']);
%  eval(['dumint=' char(i) 'int;']);
% 
% 
% 
%   for j=1:dim_tim
% 
%    clear tt
% 
%    [tt] = find(~isnan(dum_all(j,:)) & dum_all(j,:)<3000 & dum_all(j,:)>=0 );
% 
%      if length(find(~isnan(tt)))>2
% 
%       dum_all(j,find(dum_all(j,tt)<not_def))=NaN;
% 
%       try
%        dumint(j,:)=interp1(z_all(j,tt),dum_all(j,tt),zint,'spline', 'extrap');
%       catch
%        dumint(j,:)=NaN;
%       end
% 
%      else
% 
%       dumint(j,:)=NaN;
%  
%      end      
% 
%  end                                    % time-loop
% 
%  eval([char(i) 'int=dumint;']);
%  eval([char(i) '_all=dum_all;']);
% 
% end                                     % variable-loop
% 
% clear i

%   ---- MISSING data:
%
% if there is only "NaN" for a sonde => remove that time:

 jj=1;
 clear thN tkN rhN wspN ddN dateN

 thN  = th_all; % thint;
 tkN  = tk_all; %tkint;
 pN   = p_all;  %pint;
 rhN  = rh_all; %rhint;
 wspN = wsp_all; %wspint;
 ddN  = dd_all; %ddint;
 zN = z_all;
 dateN= date_files(ind_sort);

 for j=1:dim_tim

  %if all(isnan(thint(j,:))) | all(isnan(rhint(j,:))) | all(isnan(wspint(j,:))) | all(isnan(thint(j,:)))
  if all(isnan(th_all(j,:))) | all(isnan(rh_all(j,:))) | all(isnan(wsp_all(j,:)))
  tkN(jj,:) = [];
    pN(jj,:) = [];
   thN(jj,:) = [];
   rhN(jj,:) = [];
  wspN(jj,:) = [];
   ddN(jj,:) = [];
   zN(jj,:) = [];
   display(['removing ' datestr(dateN(jj), 31)])
 dateN(jj)   = [];
  jj=jj-1;
   end
   jj=jj+1;
  end


% Update time_string

dim_tim2 = size(thN,1);
dim_z2   = size(thN,2);




% % --- calc stab (Brunt-Vaisala freq.) for whole profile [ N^2=g*d(lnth)/dz ]:
% 
%  stabdry(1:dim_tim2,1:dim_z2)   = NaN;
%  stabm(1:dim_tim2,1:dim_z2)     = NaN;
%  stabtot(1:dim_tim2,1:dim_z2)   = NaN;
%  Scorsq(1:dim_tim2,1:dim_z2)    = NaN;
%  Scsq_rm(1:dim_tim2,1:dim_z2)   = NaN;
%   L  = 2.5e6 ;
%   R  = 287;
%   cp = 1006;
%  eps = 0.662;
% 
% 
%  for i=1:dim_tim2   % first time
% 
%  for j=3:dim_z2-2
% % dum = 9.81*(log(nanmean(thN(i,j+1:j+2)))-log( nanmean(thN(i,j-2:j-1)) ) )/150;
% %  stabdry(j) = sqrt(abs(dum))*sign(dum);
% 
%   game = -( nanmean(tkN(i,j+1:j+2)) - nanmean(tkN(i,j-2:j-1)) )/150;
% 
%     tm = nanmean(tkN(i,j-1:j+1));
%     es = 611.21*exp(17.502*(tm-273.16)/(tm-32.19));
%     qs = 0.622*es/(nanmean(100*pN(i,j-1:j+1))-es);
%  %   qs=0. 
% 
%   Cgam = -(9.81*(1+(L*qs)/(R*tm) )/(cp+(L^2*qs*eps)/(R*tm)) );
%   dum2 = (game-Cgam)*9.81/tm;
%   stabm(i,j) = sqrt(abs(dum2))*sign(dum2);
% 
%   dum        = 9.81*( game +9.81/cp )/tm;
%   stabdry(i,j) = sqrt(abs(dum))*sign(dum);
% 
%   stabtot(i,j) = stabdry(i,j);
%    if nanmean(rhN(i,j-1:j+1)) >85
%      stabtot(i,j) = stabm(i,j);
%    end
% 
%   Scorsq(i,j) = stabtot(i,j)^2/wspN(i,j)^2;   % Ssq - if decrease strongly with height -> lee waves!
% 
%  end
%  end
% 
% 
% 
% 
% 
% % -- smooth the Sc-profile
% 
% clear Scsq_rm
% for i=1:dim_tim2
%  Scsq_rm(i,:) = runningmean(Scorsq(i,:)',6);
% end
% 
% % -- end smoothing
% 
% 
% clear dSc crszero stabblw ublw ublw2 stablw2 crszero2
% 
% for i = 1:dim_tim2
% 
%  for j = 2:dim_z2
%   dSc(i,j) = Scsq_rm(i,j)-Scsq_rm(i,j-1);
%  end
% 
%   clear si t                                          % gets where the 0-crossing is
%  si=sign(dSc(i,:));
%  t=filter([1 1],1,si);
%  dum=find( t(1:end)==0 ) ; 
%  dum=dum-1; dum(find(dum==0))=1;
% 
%   kk=1;
%   while isnan(Scsq_rm(i,kk)) & kk < length(Scsq_rm(i,:));
%   kk     = kk+1; 
%   dum(1) = kk;  
%   end
%  
% 
%    if ~isempty(dum) & length(dum)>1
%     clear dSc_val
%       dum2 = 0;
%       kk   = 1;
% 
%      for k=1:(length(dum)-1)
%      
%       if ( Scsq_rm(i,dum(k+1))-Scsq_rm(i,dum(k)) ) < dum2  
%        dum2       = Scsq_rm(i,dum(k+1))-Scsq_rm(i,dum(k));
%        max_val(i)  = dum(k+1);
%        max_val2(i) = dum(k);       
% 
%        kk=k;
%       end
%   
% % check if abv/blw has large increase/decrease in Scsq_rm
% 
%  try
%     kkk=1;
%     kkkp1=2;
%     while (Scsq_rm(i,dum(kk+kkkp1)) - Scsq_rm(i,dum(kk+kkk))) > 0.2*dum2 & max_val(i) < dum(end)
%       max_val(i) = dum(kk + kkkp1);
%       kkkp1 = kkkp1+1;
%       kkk   = kkk+1  ;
%     end
%   catch   
%   end
% 
% 
%     kkk=0;
%     kkkp1=1;
% 
%  try
%     kkk=1;
%     kkkp1=2;
%     while (Scsq_rm(i,dum(kk-kkkp1)) - Scsq_rm(i,dum(kk-kkk))) > 0.2*dum2 
%       max_val2(i) = dum(kk - kkkp1);
%       kkkp1 = kkkp1+1;
%       kkk   = kkk+1  ;
%     end
%   catch   
%   end
% 
%          try
%            if isnan(Scsq_rm(i,max_val2(i)-1))
%             max_val2(i) = 1;
%            end
%          catch
%          end
% 
%    end
% 
%    
%    m2=dum(2);
%    crszero(i) =  zint(m2);                %  height of the Scorer parameter crossing
%    stabblw(i) = nanmean(stabtot(i,1:m2));
%    ublw(i)    = nanmean(wspN(i,1:m2));
%    zz=zint(dum);
%    dzz=zz(2:end)-zz(1:end-1);
%    %(~,mm)=nanmax(dzz);
%   
%   try
%    crszero2(i) = zint(max_val(i)) - zint(max_val2(i));
%    stabblw2(i) = nanmean( stabtot(i,max_val2(i):max_val(i)) ); 
%    dirmedian(i)= nanmedian( ddN(i,max_val2(i):max_val(i)) );
%     ublw2(i)   = nanmean(wspN(i,max_val2(i):max_val(i)) );
%    %zint(dum(mm))
%   catch 
%    crszero2(i) = NaN;
%    stabblw2(i) = NaN;
%    ublw2(i)    = NaN;
%   end
% 
%   else
% 
%    crszero(i)  = NaN;
%    stabblw(i)  = NaN;
%    ublw(i)     = NaN;
%    crszero2(i) = NaN;
%    stabblw2(i) = NaN;
%    ublw2(i)    = NaN;
%    max_val(i)  = NaN; 
%    max_val2(i) = NaN;
%    dirmedian(i)= NaN;
%   end
% 
%  end
% 
% % H*m1:
% 
% for i=1:dim_tim2  
%  mH(i)  = crszero(i)*sqrt((stabblw(i)^2/ublw(i)^2 - 4*pi^2/12000^2));
%  mH2(i) = crszero2(i)*sqrt((stabblw2(i)^2/ublw2(i)^2 - 4*pi^2/12000^2));
% end
% btwn180360=find(dirmedian>180 & dirmedian<360 );
% 
% [ 100*length(find(mH(btwn180360)>pi/2 & mH(btwn180360)< pi ) )/length(mH(btwn180360)) 100*length(find(mH2(btwn180360)>pi/2 & mH2(btwn180360)< pi ) )/length(mH2(btwn180360)) ]
% [ 100*length(find(mH>pi/2 & mH< pi ) )/length(mH)  100*length(find(mH2>pi/2 & mH2< pi ) )/length(mH2) ]
% 
% leew_ind2=find(mH2>pi/2 & mH2< pi );

clear L R a ans b dd dd_all ddint dim_tim dim_tim2 dim_z dim_z2 dirmedian dum dum2 dum_all
clear sort_date dum_name dumint dzz eps es ff fmt fname1 fro_date game gf i ichos ii ind_len
clear ind_sort j jj kk kkk kkkp1 leew_ind2 len_rec m2 mH mH2 max_val max_val2 not_def
clear p_all path_data_store pint plev r rhN rhint s si sonde_file t td th th_all the thint
clear thv tk tkint tm to_date tt wsp_all wspint yyyy yyyy_good zlev zz zint

%save ('/scratch/MATLAB/Valentia_03953/Valentia_03953');
%save ('/scratch/MATLAB/Ekofisk_01400/Ekofisk_01400');
save ('/scratch/MATLAB/Lerwick_03005/Lerwick_03005');

%for i=80:2:90;
%close all
%figure(i)
%plot(stabtot(i,:),zint,'g'); hold on
%plot(wspN(i,:)/100,zint,'k'); hold on
%plot([-0.1 0.5],[crszero(i) crszero(i)],'k' )
%plot([-0.1 0.6],[zint(max_val(i)) zint(max_val(i))],'r' )
%plot([-0.1 0.6],[zint(max_val2(i)) zint(max_val2(i))],'r' )
%figure(i+1);plot(Scsq_rm(i,:),zint,'m');
%figure(3) ;plot(dSc(i,:),zint,'r');
%end


