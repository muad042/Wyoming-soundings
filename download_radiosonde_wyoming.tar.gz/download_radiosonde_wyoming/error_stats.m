function [B, R, S]=error_stats(size,pm,var_mod,var_obs,po)
%B: Bias
%R: RMSE
%S: STDE
%size: size of the array
%pm: model pressure levels
%po: observations pressure levels
%var_mod: model variable
%var_obs: corresponding observed variable

clear i
for i=1:size
        var_int_MtoO(i,:)=interp1(pm(i,:),var_mod(i,:),po(i,:),'spline');
        B1 = var_int_MtoO(i,:) - var_obs(i,:);
        SE = B1.^2;
        MSE = nanmean(SE); %mean(SE(find(isnan(SE)~=1)),2);
        B(i) = nanmean(B1);
        R(i) = sqrt(MSE);        
end
S = sqrt(R.^2 - B.^2);
%clear RMSE
%RMSE = STDE;
