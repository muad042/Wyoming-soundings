% This script will call the load-script and plot the dropsonde from a crossection:HINLOPEN
% AUTHOR: Idar Barstad, bjerknes UiB
%
clear

%  ***********   GET THE DATA:
% speed, direction, geopotential height, time, timeX,...
[ff1 dd1 gpa1 time1 b_time1 lat1 lon1 u1 v1 rh1 theta1 pres1]=load_dropsonde_IPY('/Home/siv4/ngfib/IPY/Thorpex_2008_02_27a/D20080227_124937_PRAW.nc');
[ff2 dd2 gpa2 time2 b_time2 lat2 lon2 u2 v2 rh2 theta2 pres2]=load_dropsonde_IPY('/Home/siv4/ngfib/IPY/Thorpex_2008_02_27b/D20080227_135811RAW.nc');
[ff3 dd3 gpa3 time3 b_time3 lat3 lon3 u3 v3 rh3 theta3 pres3]=load_dropsonde_IPY('/Home/siv4/ngfib/IPY/Thorpex_2008_02_27b/D20080227_140341RAW.nc');
[ff4 dd4 gpa4 time4 b_time4 lat4 lon4 u4 v4 rh4 theta4 pres4]=load_dropsonde_IPY('/Home/siv4/ngfib/IPY/Thorpex_2008_02_27b/D20080227_140817RAW.nc');
[ff5 dd5 gpa5 time5 b_time5 lat5 lon5 u5 v5 rh5 theta5 pres5]=load_dropsonde_IPY('/Home/siv4/ngfib/IPY/Thorpex_2008_02_27b/D20080227_141441RAW.nc');

theta1(find(theta1==-999))=NaN;theta2(find(theta2==-999))=NaN;theta3(find(theta3==-999))=NaN;
theta4(find(theta4==-999))=NaN;theta5(find(theta5==-999))=NaN; pres1(find(pres1==-999))=NaN;

% remove obvious errors in theta:
for j=1:5
clear th_tmp;
eval(['th_tmp=theta' num2str(j) ';'])

for i=2:length(th_tmp)
 if abs(th_tmp(i)-th_tmp(i-1)) > 3
  th_tmp(i)=NaN;
  [j,i]
 end
end
eval(['theta' num2str(j) '=th_tmp;'])
%figure(j);plot(th_tmp)
end


%  find the nearest value in theta:

clear round_ind round_val
range_deg=30;
%min_val_0=255;          % ceil(theta1(1)); 
int_val=1;              % start and interval

round_ind(1:range_deg,1:5)=NaN;  round_val(1:range_deg,1:5)=NaN;

for j=1:5               % stations

max_val_0=280;

max_val=max_val_0;     

clear th_tmp;
eval(['th_tmp=theta' num2str(j) ';'])

for ii = range_deg:-1:1

  i=length(th_tmp);
  while th_tmp(i) > max_val | isnan(th_tmp(i));  
  round_ind(ii,j) = i;
  round_val(ii,j) = th_tmp(i);
  i=i-1;
   if i==0 
    break
   end
  end

  while isnan(round_val(ii,j)),
  round_ind(ii,j)=round_ind(ii,j)+1;
  round_val(ii,j)=th_tmp(round_ind(ii,j));
  end

%  [round_val(ii,j) th_tmp(i+1)]
  
  max_val=max_val-int_val;
end

end          % number of sondes
round_ind(find(round_ind==0))=NaN;
round_val(find(round_val==0))=NaN;

round_val2=round_val; round_val2(:,1:5)=NaN;

% drop the equal values:
for i=1:5
for j=2:length(round_val)
 if round_val(j,i)==round_val(j-1,i)
   round_val(j-1,i)=NaN;
 else
  break
 end
end
end


%   ********* CALCULATE SOME VALUES: 
% U and V in kt:
[uf1,vf1]=ddff2uv(dd1',ff1'*2);
[uf2,vf2]=ddff2uv(dd2',ff2'*2);
[uf3,vf3]=ddff2uv(dd3',ff3'*2);
[uf4,vf4]=ddff2uv(dd4',ff4'*2);
[uf5,vf5]=ddff2uv(dd5',ff5'*2);

uf1=uf1';vf1=vf1';uf2=uf2';vf2=vf2';uf3=uf3';vf3=vf3';uf4=uf4';vf4=vf4';uf5=uf5';vf5=vf5';

% NEED TO scrink the z-axes (to km) so that it compares to x-axis
  
% fraction of total data length indicated upsfront:

z_fac=0.40*(1/1000);                    % decide the height of data (lower value, lower height) 

yax(1)=0; yax(2)=max(gpa1)*z_fac;
diff_y=yax(2)-yax(1);
ff_fac=200*z_fac/diff_y;                 % scale the wind speed (red line)

% nice plot on a graph:
spread(1)=yax(1); spread(2)=yax(2)/4; spread(3)=yax(2)/2;spread(4)=yax(2)*3/4;spread(5)=yax(2);

lon_dum1(1:length(u1))=spread(1);
lon_dum2(1:length(u2))=spread(2);
lon_dum3(1:length(u3))=spread(3);
lon_dum4(1:length(u4))=spread(4);
lon_dum5(1:length(u5))=spread(5);

b_int=15;                                % distance between arrows
thi=[(max_val_0-1):-1:(max_val_0-range_deg+1)];

% dropsondes wind barbs and profile of wind:

val='kt'

figure(6)
title_txt=['Windbarb and profile of speed; not correct horizontally shifted. Theta starts at:' num2str(max_val_0) ]; title(title_txt)
xlim([(yax(1)-yax(2)*0.2) yax(2)+yax(2)*0.2])
ylim([(yax(1)-yax(2)*0.2) (yax(2)+yax(2)*0.2)])   % altitude limits in decameters

int=round(length(gpa1)/b_int);
plot_windbarb_vert(uf1(1:int:end),vf1(1:int:end),gpa1(1:int:end)*z_fac,lon_dum1(1:int:end)',1,val)
hold on
plot([lon_dum1(1) lon_dum1(1)],[gpa1(1)*z_fac gpa1(end)*z_fac])
plot([lon_dum1(1)'+ff1*ff_fac],gpa1*z_fac,'r')
plot([lon_dum1(1)'+(theta1-273.16)*ff_fac],gpa1*z_fac,'g')
th=theta1(find(~isnan(theta1))); gp=gpa1(find(~isnan(theta1))); clear b i j; [b,i,j] = unique(th);
gpi=interp1(th(i),gp(i),fliplr(thi));
%plot([lon_dum1(1)'+(thi-273.16)*ff_fac],gpi*z_fac,'.')
plot([repmat(lon_dum1(1),1,length(gpi*z_fac))],gpi*z_fac,'.')
geo_x(1,1:length(thi))=gpi*z_fac;

% gpi=interp1(th(i),gp(i),fliplr(thi))
% figure(10); plot(th-273.16,gp,'r.'); hold on
% plot([repmat(0,1,length(gpi))],gpi,'.')
% grid; ylim([0 3000]);


int=round(length(gpa5)/b_int);
plot_windbarb_vert(uf5(1:int:end),vf5(1:int:end),gpa5(1:int:end)*z_fac,lon_dum5(1:int:end)',1,val)
plot([lon_dum5(1) lon_dum5(1)],[gpa5(1)*z_fac gpa5(end)*z_fac])
plot([lon_dum5(1)'+ff5*ff_fac],gpa5*z_fac,'r')
plot([lon_dum5(1)'+(theta5-273.16)*ff_fac],gpa5*z_fac,'g')
th=theta5(find(~isnan(theta5))); gp=gpa5(find(~isnan(theta5))); [b,i,j] = unique(th);
gpi=interp1(th(i),gp(i),fliplr(thi));
plot([repmat(lon_dum5(1),1,length(gpi*z_fac))],gpi*z_fac,'.')
%plot([lon_dum5(1)'+(thi-273.16)*ff_fac],gpi*z_fac,'.')
%%plot([lon_dum5(1)'+(thi(find(isnan(gpi)))-273.16)*ff_fac],gpi(find(isnan(gpi)))*z_fac,'x')
geo_x(5,1:length(thi))=gpi*z_fac;

int=round(length(gpa2)/b_int);
plot_windbarb_vert(uf2(1:int:end),vf2(1:int:end),gpa2(1:int:end)*z_fac,lon_dum2(1:int:end)',1,val)
plot([lon_dum2(1) lon_dum2(1)],[gpa2(1)*z_fac gpa2(end)*z_fac])
plot([lon_dum2(1)'+ff2*ff_fac],gpa2*z_fac,'r')
plot([lon_dum2(1)'+(theta2-273.16)*ff_fac],gpa2*z_fac,'g')
th=theta2(find(~isnan(theta2))); gp=gpa2(find(~isnan(theta2))); [b,i,j] = unique(th);
gpi=interp1(th(i),gp(i),fliplr(thi));
%plot([lon_dum2(1)'+(thi-273.16)*ff_fac],gpi*z_fac,'.')
plot([repmat(lon_dum2(1),1,length(gpi*z_fac))],gpi*z_fac,'.')
geo_x(2,1:length(thi))=gpi*z_fac;

int=round(length(gpa3)/b_int);
plot_windbarb_vert(uf3(1:int:end),vf3(1:int:end),gpa3(1:int:end)*z_fac,lon_dum3(1:int:end)',1,val)
plot([lon_dum3(1) lon_dum3(1)],[gpa3(1)*z_fac gpa3(end)*z_fac])
plot([lon_dum3(1)'+ff3*ff_fac],gpa3*z_fac,'r')
plot([lon_dum3(1)'+(theta3-273.16)*ff_fac],gpa3*z_fac,'g')
th=theta3(find(~isnan(theta3))); gp=gpa3(find(~isnan(theta3))); [b,i,j] = unique(th);
gpi=interp1(th(i),gp(i),fliplr(thi));
%plot([lon_dum3(1)'+(thi-273.16)*ff_fac],gpi*z_fac,'.')
plot([repmat(lon_dum3(1),1,length(gpi*z_fac))],gpi*z_fac,'.')
geo_x(3,1:length(thi))=gpi*z_fac;

int=round(length(gpa4)/b_int);
plot_windbarb_vert(uf4(1:int:end),vf4(1:int:end),gpa4(1:int:end)*z_fac,lon_dum4(1:int:end)',1,val)
plot([lon_dum4(1) lon_dum4(1)],[gpa4(1)*z_fac gpa4(end)*z_fac])
plot([lon_dum4(1)'+ff4*ff_fac],gpa4*z_fac,'r')
plot([lon_dum4(1)'+(theta4-273.16)*ff_fac],gpa4*z_fac,'g')
th=theta4(find(~isnan(theta4))); gp=gpa4(find(~isnan(theta4))); [b,i,j] = unique(th);
gpi=interp1(th(i),gp(i),fliplr(thi));
%plot([lon_dum4(1)'+(thi-273.16)*ff_fac],gpi*z_fac,'.')
plot([repmat(lon_dum4(1),1,length(gpi*z_fac))],gpi*z_fac,'.')
geo_x(4,1:length(thi))=gpi*z_fac;

xlabel('South-North:: crossection through Hinlopen Strait')
ylabel('heights in km')
grid

xx_lon=[lon_dum1(1); lon_dum2(1); lon_dum3(1); lon_dum4(1); lon_dum5(1)];
plot(xx_lon,geo_x(:,1),'k-')
plot(xx_lon,geo_x(:,round(length(thi)/3)),'k-')
plot(xx_lon,geo_x(:,round(2*length(thi)/3)),'k-')
plot(xx_lon,geo_x(:,round(3*length(thi)/4)),'k-')
plot(xx_lon,geo_x(:,round(length(thi))),'k-')
%      OLDER code:
%
% ALTERNATIVE: dropsondes wind barbs and profile of theta:
xlim([0 100])
ylim([-30 300])   % altitude limits in decameters
b_int=20;

int=round(length(gpa1)/b_int);
val='kt'
plot_windbarb_vert(uf1(1:int:end),vf1(1:int:end),gpa1(1:int:end)./10,lon_dum1(1:int:end)',1,val)
hold on
plot([lon_dum1(1) lon_dum1(1)],[gpa1(1)/10 gpa1(end)/10])
rmv1=find(rh1==-999| theta1==-999 );
time1(rmv1)=[];gpa1(rmv1)=[];theta1(rmv1)=[];rh1(rmv1)=[];
plot([lon_dum1(1)'+(theta1-theta1(1))/2],gpa1./10,'r')

int=round(length(gpa2)/b_int);
plot_windbarb_vert(uf2(1:int:end),vf2(1:int:end),gpa2(1:int:end)./10,lon_dum2(1:int:end)',1,val)
plot([lon_dum2(1) lon_dum2(1)],[gpa2(1)/10 gpa2(end)/10])
rmv2=find(rh2==-999| theta2==-999 );
time2(rmv2)=[];gpa2(rmv2)=[];theta2(rmv2)=[];rh2(rmv2)=[];
plot([lon_dum2(1)'+(theta2-theta1(1))/2],gpa2./10,'r')

int=round(length(gpa3)/b_int);
plot_windbarb_vert(uf3(1:int:end),vf3(1:int:end),gpa3(1:int:end)./10,lon_dum3(1:int:end)',1,val)
plot([lon_dum3(1) lon_dum3(1)],[gpa3(1)/10 gpa3(end)/10])
rmv3=find(rh3==-999| theta3==-999 );
time3(rmv3)=[];gpa3(rmv3)=[];theta3(rmv3)=[];rh3(rmv3)=[];
plot([lon_dum3(1)'+(theta3-theta1(1))/2],gpa3./10,'r')

int=round(length(gpa4)/b_int);
plot_windbarb_vert(uf4(1:int:end),vf4(1:int:end),gpa4(1:int:end)./10,lon_dum4(1:int:end)',1,val)
plot([lon_dum4(1) lon_dum4(1)],[gpa4(1)/10 gpa4(end)/10])
rmv4=find(rh4==-999| theta4==-999 );
time4(rmv4)=[];gpa4(rmv4)=[];theta4(rmv4)=[];rh4(rmv4)=[];
plot([lon_dum4(1)'+(theta4-theta1(1))/2],gpa4./10,'r')

int=round(length(gpa5)/b_int);
plot_windbarb_vert(uf5(1:int:end),vf5(1:int:end),gpa5(1:int:end)./10,lon_dum5(1:int:end)',1,val)
plot([lon_dum5(1) lon_dum5(1)],[gpa5(1)/10 gpa5(end)/10])
rmv5=find(rh5==-999| theta5==-999 );
time5(rmv5)=[];gpa5(rmv5)=[];theta5(rmv5)=[];rh5(rmv5)=[];
plot([lon_dum5(1)'+(theta5-theta1(1))/2],gpa5./10,'r')

xlabel('crossection through Hinlopen Strait')
ylabel('heights in dekameters')

%
% ############################################################################3
% What about the stability/humidity profiles : 
%%%%%              1           %%%%%%%
figure(1)
rmv1=find(rh1==-999| theta1==-999 );
time1(rmv1)=[];gpa1(rmv1)=[];
theta1(rmv1)=[];rh1(rmv1)=[];
clear rmv1; rmv1=find(theta1>mean(theta1)+std(theta1)*1)
time1(rmv1)=[];gpa1(rmv1)=[];
theta1(rmv1)=[];rh1(rmv1)=[];

subplot(1,2,1),plot(rh1,gpa1,'r'); set(gca,'YLim',[0 3000]); set(gca,'XTick',[0:10:100]); grid
hold on
subplot(1,2,2),plot(theta1,gpa1,'k'); set(gca,'YLim',[0 3000]); set(gca,'XTick',[254:2:276]); xlim([254 276]); grid
title('Sonde 1')


%%%%%              2           %%%%%%%
figure(2)
rmv2=find(rh2==-999| theta2==-999 );
time2(rmv2)=[];gpa2(rmv2)=[];
theta2(rmv2)=[];rh2(rmv2)=[];
clear rmv2; rmv2=find(theta2>mean(theta2)+std(theta2)*2)
time2(rmv2)=[];gpa2(rmv2)=[];
theta2(rmv2)=[];rh2(rmv2)=[];

subplot(1,2,1),plot(rh2,gpa2,'r'); set(gca,'YLim',[0 3000]); set(gca,'XTick',[0:10:100]); grid
hold on
subplot(1,2,2),plot(theta2,gpa2,'k'); set(gca,'YLim',[0 3000]); set(gca,'XTick',[252:2:276]); xlim([252 276]); grid
title('Sonde 2')


%%%%%             3           %%%%%%%

figure(3)
rmv3=find(rh3==-999| theta3==-999 );
time3(rmv3)=[];gpa3(rmv3)=[];
theta3(rmv3)=[];rh3(rmv3)=[];
clear rmv3; rmv3=find(theta3>mean(theta3)+std(theta3)*3)
time3(rmv3)=[];gpa3(rmv3)=[];
theta3(rmv3)=[];rh3(rmv3)=[];

subplot(1,2,1),plot(rh3,gpa3,'r'); set(gca,'YLim',[0 3000]); set(gca,'XTick',[0:10:100]); grid
hold on
subplot(1,2,2),plot(theta3,gpa3,'k'); set(gca,'YLim',[0 3000]); set(gca,'XTick',[256:2:276]); xlim([256 276]); grid
title('Sonde 3')


%%%%%              4           %%%%%%%
figure(4)
rmv4=find(rh4==-999| theta4==-999 );
time4(rmv4)=[];gpa4(rmv4)=[];
theta4(rmv4)=[];rh4(rmv4)=[];
clear rmv4; rmv4=find(theta4>mean(theta4)+std(theta4)*4)
time4(rmv4)=[];gpa4(rmv4)=[];
theta4(rmv4)=[];rh4(rmv4)=[];

%[ax,hl1,hl2]=plotxx(rh4,gpa4,theta4-200,gpa4)
%set(hl1(1:2),'YLim',[0 3000]); grid; title('Sonde 4')

subplot(1,2,1),plot(rh4,gpa4,'r'); set(gca,'YLim',[0 3000]); set(gca,'XTick',[0:10:100]); grid
hold on
subplot(1,2,2),plot(theta4,gpa4,'k'); set(gca,'YLim',[0 3000]); set(gca,'XTick',[260:2:276]); xlim([260 276]); grid
title('Sonde 4')


%%%%%              5           %%%%%%%

figure(5)
rmv5=find(rh5==-999| theta5==-999 );
time5(rmv5)=[];gpa5(rmv5)=[];
theta5(rmv5)=[];rh5(rmv5)=[];
clear rmv5; rmv5=find(theta5>mean(theta5)+std(theta5)*5)
time5(rmv5)=[];gpa5(rmv5)=[];
theta5(rmv5)=[];rh5(rmv5)=[];

subplot(1,2,1),plot(rh5,gpa5,'r'); set(gca,'YLim',[0 3000]); set(gca,'XTick',[0:10:100]); grid
hold on
subplot(1,2,2),plot(theta5,gpa5,'k'); set(gca,'YLim',[0 3000]); set(gca,'XTick',[264:2:276]); xlim([264 276]); grid
title('Sonde 5')

