clear
close all
warning off

center_lon=10.0;
center_lat=60;
m_proj('Lambert Conformal Conic','lon',[-30 50],'lat',[43 85]...
       ,'clo',center_lon,'par',[45 45],'rec','off'); hold on
%m_proj('Stereographic','lon',-33.0,'lat',60.0,'rad',10,'rec','on','rot',00);hold on;
%m_proj('Orthographic','lon',0,'lat',73,'rad',14,'rec','on','rot',50);
%ht=title('');
m_coast('patch',[.7 .7 .7],'Linewidth',[1]);m_grid('FontSize',[16],'FontWeight','bold','FontName','Times','box','fancy','tickdir','in');
%clf;m_gshhs_c('patch',[.7 .7 .7],'Linewidth',[1]);m_grid('FontSize',[16],'FontWeight','bold','FontName','Times','box','fancy','tickdir','in');
%clf;m_gshhs_l('patch',[.7 .7 .7],'Linewidth',[1]);m_grid('FontSize',[16],'FontWeight','bold','FontName','Times','box','fancy','tickdir','in');
%clf;m_gshhs_i('patch',[.7 .7 .7],'Linewidth',[1]);m_grid('FontSize',[16],'FontWeight','bold','FontName','Times','box','fancy','tickdir','in');
%clf;m_gshhs_h('patch',[.7 .7 .7],'Linewidth',[1]);m_grid('FontSize',[16],'FontWeight','bold','FontName','Times','box','fancy','tickdir','in');
%m_gshhs_f('patch',[.7 .7 .7],'Linewidth',[1]);m_grid('FontSize',[16],'FontWeight','bold','FontName','Times','box','fancy','tickdir','in');
%m_plot([0 5],[70 72],'r');
%m_elev('pcolor');m_coast('Linewidth',2);shading flat; colorbar;m_grid('FontSize',[16],'FontWeight','bold','FontName','Times','box','fancy','tickdir','in');
%m_tbase('contourf',[0:50:3000]);m_gshhs_f('Linewidth',0.5,'Color','b');shading flat; colorbar; colormap(flipud(summer));
%m_grid('FontSize',[16],'FontWeight','bold','FontName','Times','box','fancy','tickdir','in');
%[x,y]=m_ll2xy(2.5,62);[h]=text(x,y,'Norwegian Sea');set(h,'Rotation',[60],'FontSize',[15],'FontWeight','bold','FontName','Times'); clear x y h;
%[x,y]=m_ll2xy(24,75);[h]=text(x,y,'Barents Sea');set(h,'Rotation',[0],'FontSize',[15],'FontWeight','bold','FontName','Times'); clear x y h;
%[x,y]=m_ll2xy(-15,70);[h]=text(x,y,'Greenland Sea');set(h,'Rotation',[55],'FontSize',[15],'FontWeight','bold','FontName','Times'); clear x y h;
%[x,y]=m_ll2xy(-3,82);[h]=text(x,y,'Arctic ocean');set(h,'Rotation',[0],'FontSize',[15],'FontWeight','bold','FontName','Times'); clear x y h;
