function [ib,d, id] = nearest_value2(a,b);
% function [d,ib,id]=nearest_value(a,b)
% "a" and "b" are  row vectors
% "d" is the abs. diff between elements in "a" the corresponding 
%  value in minumum distance to elements in "b". 
%  The "id" gives the index for the nearest cell value. 

%
% An example:
%  a =[ 1, 2, 3, 4, 5];
%  b =[2.8, 1, 100];
%
%  gives:
%
%  d  = 0  0.8  0.2  1.2  2.2
%  
%  ib = 2 1 1 1 1
% 

 [sizea] = size(a);
 [sizeb] = size(b);

 if sizea(1)>1 || sizeb(1)>1 ;
   error('You need to have ROW vectors!')
   return
 end

 m = size(a,2); n = size(b,2);
 [c,p] = sort([a,b]);
 q = 1:m+n; q(p) = q;
 t = cumsum(p>m);
 r = 1:n; r(t(q(m+1:m+n))) = r;
 s = t(q(1:m));
 id = r(max(s,1));
 iu = r(min(s+1,n));
 [d,it] = min([abs(a-b(id));abs(b(iu)-a)]);
 ib = id+(it-1).*(iu-id);

