%Compute the stability of a vertical profile
clear
[obs_file] = textread('sonde_1215022008m','','headerlines',4);
pobs = obs_file(:,1);
zobs = obs_file(:,2);
tcobs = obs_file(:,3);
thobs = obs_file(:,9);
[I]=find(pobs >= 700);
p_obs = pobs(I);
z_obs = zobs(I);
tc_obs = tcobs(I);
th_obs = thobs(I);
clear I pobs tcobs zobs

z=z_obs;
tc=tc_obs;
th=th_obs;
figure(1);plot(th,z);grid; %hold on; plot(tc,z);hold off 

%znew = [z_obs(1):50:z_obs(end)];
%tcnew = interp1(z_obs,tc_obs,znew,'spline');
%tcnew = tc + 273.16;
% Compute BV frequency according to Durran and Klemp (1982)
% Eq 1a from the above paper.
%g = 9.8;  % m/s2; 
%Cp = 1004;% J/Kg/K; 
%dz = 50;  % m;
%dt = diff(tcnew);
%Nsqr(1)=NaN;
%for i=2:length(tcnew)
%   Nsqr(i) = (g/tcnew(i)) * ( (dt(i-1)/dz)+(g/Cp) );
%   %Nsqr(i-1) = (g/tcnew(i)) * ( ((tcnew(i)-tcnew(i-1))/dz)+(g/Cp) );
%end
%N = sqrt(abs(Nsqr)).*sign(Nsqr);
%dN(1) = NaN; dN(2:length(znew)) = diff(Nsqr);DN=dN/dz; 
%figure(1); plot(tcnew,znew, 'b'); grid on; 
%figure(2);plot(N,znew, 'r');grid on;
%figure(3); plot(Nsqr,znew, 'r');grid on;
%figure(4); plot(DN,znew, 'g'); grid on;

dz = diff(z);
dt = diff(tc);
       
[I] = find(sign(dt)==1 | sign(dt)==0);
if (length(I) == 0)
    strength_inv = NaN;
    inv_hgt = NaN;
    return;
else 
    [I1] = diff(I);
    [I2] = find(I1~=1);
end         
if (isempty(I2) == 1)    % continuous array => only one inversion
    t2=tc(I(end)+1);
    t1=tc(I(1));
    dt_inv = tc(I(end)+1)-tc(I(1));
    dz_inv = z(I(end)+1)-z(I(1));
    strength_inv = dt_inv/dz_inv; 
    inv_hgt = z(I(1)); 
    %'Only one inversion is found, whose strength (dt/dz) is ....'
    %strength_inv
else
    count1 = 1;
    I2(length(I2)+1) = length(I);
    for i = 1:length(I2)  % no. of inversions = length(I2)+1
       count2 = I2(i);
       t2(i)=tc(I(count2)+1);
       t1(i)=tc(I(count1));
       dt_inv(i) = tc(I(count2)+1)-tc(I(count1));
       dz_inv(i) = z(I(count2)+1)-z(I(count1));
       strength_inv(i) = dt_inv(i)/dz_inv(i);
       inv_hgt(i) = z(I(count1));
       count1 = count2 + 1;
    end 
    %'There are more than one inversions, with strengths (dt/dz) ....'
    %strength_inv
end 
