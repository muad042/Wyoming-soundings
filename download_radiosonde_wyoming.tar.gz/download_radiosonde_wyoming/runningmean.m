function da_new = runningmean(varargin)
% function output   = runningmean(data_str,incr), 
%
% This function takes the time-gridded inputdata
% and makes a running mean out of it.
%
%  -------------------------------------------------
%  OPT=1:
% 'data_str' = data_str to get a running mean from
%
% 'incr'     = increment in spacing for new data_string
%           (e.g. 2=> a value for every second cell in data_str)
%   ------------------------------------------------
%
%  AUTHOR: Idar.Barstad@gfi.uib.no, Bergen: 27th Oct 2005.
%  Modified:  --" -- 26th Jan 09 


error(nargchk(1,inf,nargin));

if (isempty(varargin))
    disp('You need to set the data and intervals as input arguments')
    return
end

if nargin<2,
    disp('Too few inputs');
    return
end
if nargin>2,
    disp('Too many inputs');
    return
end

if nargin==2,
   opt=1;  
   data=varargin{1};
   incr=varargin{2};
end


[r c] = size(data);

if c>r,
  disp('ERROR: There are more columns than lines');
  return
end


%    ---------------   START OF THE JOB   -------
%
%     the new data_string - filled with NaN's.

 da_new(1:r,1)=NaN;


 start_ind = incr;
 end_ind   = r - incr + 1;

for jj = start_ind : end_ind
   
 da_new(jj,1) = mean( data( jj-incr+1 : jj+incr-1 ) );
 
end


return
