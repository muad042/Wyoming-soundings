clear
close all
path_data_mod=['/scratch/MATLAB/relance_runs/'];
s=dir(path_data_mod);
[a b]=size(s); ii=1;
for i=3:a
        if strcmp(s(i).name(1:3),'d01')==1
           valid_model_files(ii) = {s(i).name};
           ii=ii+1;
        end
end    