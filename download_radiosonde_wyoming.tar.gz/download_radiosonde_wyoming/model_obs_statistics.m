% This code estimates RMSE/BIAS/STDE of the model profiles with respect to
% the vertical profile data for different stations.

clear
close all

%%--Valentia profile
load ('/scratch/MATLAB/Valentia_03953/Valentia_03953');     
path_data_mod=['/scratch/MATLAB/relance_runs/2-way_nesting/Valentia_03953/'];

%% Lerwick profile
%load ('/scratch/MATLAB/Lerwick_03005/Lerwick_03005'); 
%path_data_mod=['/scratch/MATLAB/relance_runs/Lerwick_03005/'];

%% Ekofisk profile
%load ('/scratch/MATLAB/Ekofisk_01400/Ekofisk_01400'); 
%path_data_mod=['/scratch/MATLAB/relance_runs/Ekofisk_01400/'];

%% Extract the profile data between 2008.02.15:00Z and 2008.03.19:12Z
yyyy=str2num(datestr(dateN,'yyyy'));
mm=datestr(dateN,'mm');
dd=datestr(dateN,'dd');
hh=datestr(dateN,'HH');
mdh = str2num(strcat(mm,dd,hh));
[I]=find(yyyy==2008 & mdh >= 21500 & mdh <= 31912 );

%% Extract the data below 800 hPa level
for i = 1: length(I)
   clear obs_file IN pobs zobs tcobs tdobs wspd wdir
   [IN]=find(pN(I(i),:) >= 800);
   p_obs(i,IN) = pN(I(i),IN);
   z_obs(i,IN) = zN(I(i),IN);
   tk_obs(i,IN) = tkN(I(i),IN);
   wspd_obs(i,IN) = wspN(I(i),IN);
   wdir_obs(i,IN) = ddN(I(i),IN);    
end

%% Replace erroneous values with NaN
clear i K
for i = 1:length(I)
   [K]=find(p_obs(i,:) == 0 | wspd_obs(i,:) < 0 );
   p_obs(i,K) = NaN;
   z_obs(i,K) = NaN;
   tk_obs(i,K) = NaN;
   wdir_obs(i,K) = NaN;
   wspd_obs(i,K) = NaN;
end

%% Get U and V components from wspd and wdir, in knots
clear u_obs v_obs
for i = 1: length(I)
   [u_obs(i,:),v_obs(i,:)] = ddff2uv(wdir_obs(i,:), wspd_obs(i,:));
end

%% Find the strength of the temperature inversion and the inversion height
clear  i obs_file IN pobs zobs tcobs tdobs
for i = 1:length(I)
[A,B] = calc_inversion(tk_obs(i,:),z_obs(i,:));
strength_inv(i,1:length(A)) = A;
inv_hgt(i,1:length(B)) = B;
clear A B
end
clear i M N

% Fill NaNs at places with no inversions
for i= 1:length(I)
   [M]=find(strength_inv(i,:)==0 ) ; %& inv_hgt(i,:)==0);
   strength_inv(i,M)=NaN;
   inv_hgt(i,M)=NaN;
end
clear M IN INV i

%% There might be multiple inversions for a particular sounding. Find the
%% strongest of those. Then, if the strongest inversion is less than 0.005
%% per meter, ignore it.
[INV,IN] = max(strength_inv,[],2);
INV(find(isnan(INV)==1))=0;
INV(find(INV<0.005))=0;

% Get the inversion height for the strongest inversion.
for i=1:length(I)
    INVH(i)=inv_hgt(i,IN(i));   
end    

%% Get wind speed and direction at the level of inversion
clear i IN
for i=1:length(I)
    if isnan(INVH(i))
        WD(i)=NaN;
        WS(i)=NaN;
    else    
        [IN] = find(z_obs(i,:)==INVH(i));
        WD(i) = wdir_obs(IN);
        WS(i) = wspd_obs(IN);
    end    
    clear IN
end    

% Read model data
clear a b model_files s K i ii plev tc td u v hh dd mm x tot_files
s=dir(path_data_mod);
[a b]=size(s); ii=1;
for i=3:a
        if strcmp(s(i).name(1:3),'d01')==1
           model_files(ii) = {s(i).name};
           ii=ii+1;
        end
end
unix('rm -f d0*.txt');
unix('ln -sf ../relance_runs/Valentia_03953/d01*.txt .');
%unix('ln -sf ../relance_runs/Lerwick_03005/d01*.txt .');
%unix('ln -sf ../relance_runs/Ekofisk_01400/d01*.txt .');

clear dummy dummy1 dummy2 K L M
[dummy]=char(model_files);
m=0;s=0;

% getting time strings
for i = 1: length(model_files)
    clear yyyy mm dd hh n
    yyyy = str2double(dummy(i,5:8));
    mm = str2double(dummy(i,10));
    dd = str2double(dummy(i,12:13));
    hh = str2double(dummy(i,15:16));
    n = datenum(yyyy,mm,dd,hh,m,s);
    model_times(i,:) = datestr(n,0);
end
[dummy1]=datenum(dateN(I));  % Array with the date/time info of observations
[dummy2]=datenum(model_times); % Array with the data/time info of model data

% Match the date/time info from the model with that of the observations and
% extract the valid model data
[K,L,M]=nearest_value2(dummy1,dummy2'); 
[valid_model_files]=model_files(K);

for i =1:length(valid_model_files)
    [mod_file] = textread(char(valid_model_files(i)));
    plev = mod_file(:,1);
    tc   = mod_file(:,2)+273.16;
    td   = mod_file(:,3);
    u    = mod_file(:,4);
    v    = mod_file(:,5);
    [IN]=find(plev >= 800);
    p_mod(i,IN) = plev(IN);
    [K] = find(p_mod(i,:)==0 ); %|| p_mod(i,IN)==NaN)
    p_mod(i,K) = plev(K); % (plev(K-1)+plev(K+1))*0.5;
    tc_mod(i,IN) = tc(IN);tc_mod(i,K) = tc(K);
    td_mod(i,IN) = td(IN);td_mod(i,K) = td(K);
    u_mod(i,IN) = u(IN);u_mod(i,K) = u(K);
    v_mod(i,IN) = v(IN);v_mod(i,K) = v(K);
end

for i=1:length(valid_model_files)
   [wdir_mod(i,:),wspd_mod(i,:)]=uv2ddff(u_mod(i,:),v_mod(i,:));
end

%Conversion from radians to degrees
dd_mod = sin(wdir_mod.*pi/180);
dd_obs = sin(wdir_obs.*pi/180);

% Vertical interpolation of model into observations, at every time step
clear i
if isequal(length(I),length(valid_model_files))==1
    [BIAS, RMSE, STDE] = error_stats(length(I),p_mod,wspd_mod,wspd_obs,p_obs);
    [R1, R2, R3, R4, B1, B2, B3, B4] =  error_stats_1(length(I),p_mod,wspd_mod,wspd_obs,p_obs,RMSE,BIAS);
else
    'length(obs_files) and length(mod_files) are different'
end

% Plot wind barbs for the wind at a reference height.
clear K i ref_z u v z uu vv y x unit J a b xa ya
ref_z=200;
unit='kt';
for i=1:length(I)
    [K,J]=nearest_value2(ref_z,z_obs(i,:));    
    u(i)=u_obs(i,K); 
    v(i)=v_obs(i,K);
    z(i)=z_obs(i,K);
end
[uu]=u(1,1:4:length(I));
[vv]=v(1,1:4:length(I));
xa = [1:4:length(I)];
ya = 4; % Arbitrary value
scale= 60;
[a,b]=plot_windbarb_test(uu,vv,ya,xa,scale,unit);
set(a,'LineWidth',[2]);set(gca,'XLim',[1 length(I)],'YLim',[-scale/2 scale/2]);

%Plot time series of the RMSE/BIAS/STDE
clear M1 M2 M3
T = dateN(I);
[M1]=find(INV>=0.025);
[M2]=find(INV>=0.01 & INV<0.025);
[M3]=find(INV<0.01 & INV >=0.005);
ts1 = timeseries(BIAS,T);
ts2 = timeseries(BIAS(M1),T(:,M1));
ts3 = timeseries(BIAS(M2),T(:,M2));
ts4 = timeseries(BIAS(M3),T(:,M3));
ts1.TimeInfo.Units = 'days';
ts1.TimeInfo.Format = 'yyyy-mm-dd';
ts1.TimeInfo.Start  = '2008-02-15 00:00:00';
ts2.TimeInfo.Units = 'days';
ts2.TimeInfo.Format = 'yyyy-mm-dd';
ts2.TimeInfo.Start  = '2008-02-15 00:00:00';
ts3.TimeInfo.Units = 'days';
ts3.TimeInfo.Format = 'yyyy-mm-dd';
ts3.TimeInfo.Start  = '2008-02-15 00:00:00';
ts4.TimeInfo.Units = 'days';
ts4.TimeInfo.Format = 'yyyy-mm-dd';
ts4.TimeInfo.Start  = '2008-02-15 00:00:00';

figure(101);
           [h]=plot(ts1); grid; hold on;
           %[h1]=plot(ts2,'o');
           %[h2]=plot(ts3,'o');
           %[h3]=plot(ts4,'o'); 
           hold off;
title('BIAS of wind speed for the Valentia sounding (51.93N, 10.25E)');
ylabel('BIAS');
%legend('BIAS','Inv>=0.025 ^{0}Cm^{-1}','0.01<=Inv<0.025 ^{0}Cm^{-1}',...
%        '0.005<=Inv<0.01 ^{0}Cm^{-1}','Location','NorthEast'); legend boxoff;
set(h,'LineWidth',[1]);
%set(h1,'MarkerEdgeColor','r','MarkerSize',[10],'MarkerFaceColor','r');
%set(h2,'MarkerEdgeColor','g','MarkerSize',[10],'MarkerFaceColor','g');
%set(h3,'MarkerEdgeColor','b','MarkerSize',[10],'MarkerFaceColor','b');
set(gca,'XLim',[datenum(T(1)) datenum(T(end))]);%,...
        %'XTick',[datenum(T(1));datenum(T(16));datenum(T(31));...
        %         datenum(T(46));datenum(T(61))]);
datetick('x',29,'keeplimits','keepticks');

clear a b c d R11 R12 R13 R14
[a]=find(isnan(R1));[b]=find(isnan(R2));[c]=find(isnan(R3));[d]=find(isnan(R4));
R1(a)=0;R2(b)=0;R3(c)=0;R4(d)=0;
R11 = R1;
R12 = R1+R2;
R13 = R12+R3;
R14 = R13 + R4;
clear R1 R2 R3 R4
figure(102);clear h4 h5 h6 h7 h      
           [h4]=bar(datenum(T),R14); grid; hold on;
           [h5]=bar(datenum(T),R13);
           [h6]=bar(datenum(T),R12);
           [h7]=bar(datenum(T),R11);
%set(gca,'XLim',[datenum(T(1)) datenum(T(end))],...
%        'XTickLabel',[]);           
set(h4,'LineWidth',[0.5],'FaceColor','b');%[0.75 0.75 0.75]);
set(h5,'LineWidth',[0.5],'FaceColor','y');%[0.5 0.5 0.5]);
set(h6,'LineWidth',[0.5],'FaceColor','g');%[0.25 0.25 0.25]);
set(h7,'LineWidth',[0.5],'FaceColor','r');%[0 0 0]);
%[h]=plot(ts1); hold off;
%set(h,'LineWidth',[2],'Color','k');
set(gca,'XLim',[datenum(T(1)) datenum(T(end))]);%,...
        %'XTick',[datenum(T(1));datenum(T(16));datenum(T(31));...
        %         datenum(T(46));datenum(T(61))]);
datetick('x',29,'keeplimits','keepticks');
title('RMSE of wind speed for the Valentia sounding (51.93N, 10.25W)');
ylabel('RMSE');
legend('1500<RMSE<=2000 m','1000<RMSE<=1500 m','500<RMSE<=1000 m','RMSE<=500 m');legend boxoff;

% clear ii i hh dd mm plev tc td u v SE MSE M1 M2 M3 h1 h2 h3 obs_file mod_file tc_int_MtoO
% for i = 1:length(good_files) 
%  figure(i);
%  tc_int_MtoO(i,:)=interp1(p_mod(i,:),wspd_mod(i,:),p_obs(i,:),'spline');
%  [h]=plot(wspd_obs(i,:),p_obs(i,:), 'r'); hold on;
%  plot(wspd_mod(i,:),p_mod(i,:), 'g'); 
%  plot(tc_int_MtoO(i,:),p_obs(i,:), 'b'); hold off;
%  set(gca,'YDir','reverse');
%  legend('Obs','Model','Interpolated');
%  ylabel('Pressure (hPa)'); xlabel('Tc (^{0}C)');
%  obs_file=char(good_files(i));mod_file=char(valid_model_files(i));
%  hh_o=obs_file(7:8);dd_o=obs_file(9:10);mm_o=obs_file(11:12);yyyy=obs_file(13:16);
%  [h1]=title(strcat(num2str(yyyy),'-',num2str(mm_o,'%02d'),'-',num2str(dd_o,'%02d'),':',num2str(hh_o),'h'));
%  set(h1,'FontName','times','FontWeight','b','FontSize',[12]);
% end
% clear ii i hh dd mm h h1 IN K
% save stn-03953_d01
