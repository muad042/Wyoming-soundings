clear
[obs_file] = textread('sonde_1215022008m','','headerlines',4);
pobs = obs_file(:,1);
zobs = obs_file(:,2);
tcobs = obs_file(:,3);
[I]=find(pobs >= 700);
p_obs = pobs(I);
z_obs = zobs(I);
tc_obs = tcobs(I);
clear I pobs tcobs zobs

g = 9.8;  
Cp = 1004;
dz = diff(z_obs); 
dt = diff(tc_obs);
for i=2:length(z_obs)
   Nsqr(i-1) = (g/tc_obs(i)) * ( (dt(i-1)/dz(i-1))+(g/Cp) );
end
N1(1) = NaN; N1(2:length(z_obs)) = Nsqr;
figure(2); plot(tc_obs,z_obs, 'b'); grid on; hold on;
           plot(N1,z_obs, 'r'); hold off;