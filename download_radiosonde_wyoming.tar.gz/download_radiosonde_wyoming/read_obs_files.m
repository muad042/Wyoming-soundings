% This code estimates RMSE of the model profiles with respect to the observations
% iles
clear
close all
path_data_store=['/scratch/MATLAB/download_radiosonde_wyoming/'];

fro_date =datenum('01.01.2000','dd.mm.yyyy');
to_date  =datenum('31.12.2009','dd.mm.yyyy');


clear s i a b ii yyyy_good
s=dir(path_data_store);
[a b]=size(s); ii=1;

for i=1:a
  if length((s(i).name))==17
  yyyy=s(i).name(13:16);
   if yyyy >= datestr(fro_date,'yyyy') & yyyy <= datestr(to_date,'yyyy') ;
   yyyy_good(ii)={(s(i).name)}; ii=ii+1;
   end
 end
end

clear i fro_date to_date dummy ii j s yyyy a b
for i = 1:length(yyyy_good)
   clear obs_file IN pobs tcobs tdobs wdir_obs wspd_obs
   [obs_file] = textread(char(yyyy_good(i)),'','headerlines',4);
   pobs = obs_file(:,1);
   zobs = obs_file(:,2);
   tcobs = obs_file(:,3);
   tdobs = obs_file(:,4);
   wdir_obs = obs_file(:,7);
   wspd_obs = obs_file(:,8);
   thobs = obs_file(:,9);
   [IN]=find(pobs >= 700);
   p_obs(i,IN) = pobs(IN);
   z_obs(i,IN) = zobs(IN);
   tc_obs(i,IN) = tcobs(IN);
   td_obs(i,IN) = tdobs(IN);
   th_obs(i,IN) = thobs(IN);
   wspd(i,IN) = wspd_obs(IN);
   wdir(i,IN) = wdir_obs(IN);
end
% Get U and V components from wspd and wdir, in knots
%[u_obs,v_obs] = ddff2uv(wdir, wspd); 
%for i = 1:length(wspd)
%    u_obs(i) = -1 * 1.94386 * wspd(i) * sin(wdir(i)*pi/180);
%    v_obs(i) = -1 * 1.94386 * wspd(i) * cos(wdir(i)*pi/180);
%end

clear i K
for i = 1:length(yyyy_good)
   [K]=find(p_obs(i,:) == 0);
   p_obs(i,K) = NaN;
   z_obs(i,K) = NaN;
   tc_obs(i,K) = NaN;
   td_obs(i,K) = NaN;
   th_obs(i,K) = NaN;
   wdir(i,K) = NaN;
   wspd(i,K) = NaN;
end

clear  i obs_file IN pobs zobs tcobs tdobs wdir_obs wspd_obs
%for i = 1:length(yyyy_good)
%[A,B] = calc_inversion(tc_obs(i,:),z_obs(i,:));
%strength_inv(i,1:length(A)) = A;
%inv_hgt(i,1:length(B)) = B;
%clear A B
%end
%clear i M N

% for i= 1:length(yyyy_good)
%    [M]=find(strength_inv(i,:)==0 & inv_hgt(i,:)==0);
%    strength_inv(i,M)=NaN;
%    inv_hgt(i,M)=NaN;
% end
% clear M I INV
% [INV,I] = max(strength_inv,[],2);   % Get the strongest inversion at individual times
% INV(find(isnan(INV)==1))=0;

for i = 1:30:length(yyyy_good) 
 figure(i);
 [h]=plot(th_obs(i,:),p_obs(i,:), 'r'); grid;
 set(gca,'YDir','reverse');
 legend('Obs','Model','Interpolated');
 [h1]=title(strcat(num2str(hh,'%02d'),'Z\_',num2str(dd),'Feb'));
 set(h1,'FontName','times','FontWeight','b','FontSize',[12]); 
 ylabel('Pressure (hPa)'); xlabel('Tc (^{0}C)');
 hh = hh+12;
  if (i==ii) 
    dd = dd+1;
    hh = 0;
    ii = ii+2;
  end 
clear h h1 
end
clear ii i hh dd mm h h1 IN K

