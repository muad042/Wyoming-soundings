function [d,s] = uv2ddff(u,v);
% This function turns u-component and v-component into 
% direction (dd) and speed(ff) according to WMO standard
% AUTHOR: Idar Barstad, Bergen Nov '05
%
%
rad2deg=57.29577951;

%%%%%%%%%%%%%%%%%%%%%%%%%%
le=length(u);
%d=zeros(1,le); s=zeros(1,le);
d=zeros(le,1); s=zeros(le,1);

for i=1:le


if ~isnan(v(i)) & v(i) < 0
  d(i) = rad2deg*atan(u(i)/v(i));
  if u(i) >= 0  ; d(i) = d(i) + 360; end
%  s = sqrt(u*u + v*v);
elseif v(i) == 0 & ~isnan(v(i))
  if u(i) < 0
   d(i) = 90;
%   s = -u;
  elseif u(i) == 0
   d(i) = 0;
%   s = 0;
  elseif u(i) > 0
   d(i) = 270;
%   s = u;
  end
elseif v(i) > 0 & ~isnan(v(i))
  d(i) = 180 + rad2deg*atan(u(i)/v(i));
  %  s = sqrt(u*u + v*v);

elseif isnan(v(i))
 d(i) = NaN;
 u(i) = NaN;
 v(i) = NaN;
end

end
  %s = rot90(sqrt(u.*u + v.*v),-1);
  s = rot90(sqrt(u.^2 + v.^2),-1);