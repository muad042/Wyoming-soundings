
clear
path_data_store=['/media/pp/data/sonde_Valentia/'];

fro_date =datenum('01.01.2000','dd.mm.yyyy');
to_date  =datenum('31.12.2009','dd.mm.yyyy');


clear s i a b ii yyyy_good
s=dir(path_data_store);
[a b]=size(s); ii=1;

for i=1:a

 if length((s(i).name))==4
  yyyy=str2num(s(i).name(1:4));
   if yyyy >= str2num(datestr(fro_date,'yyyy')) & yyyy <= str2num(datestr(to_date,'yyyy')) ;
    yyyy_good(ii)=yyyy; ii=ii+1;
   end
 end

end


% first get the list of files incl. file-path:  

clear good_files ind_len
ii=1;

for i = 1:length(yyyy_good)

 unix([ 'rm toto' ]);
 unix([ 'find ' path_data_store num2str(yyyy_good(i)) '/. >toto']);
 [fname1]=textread('toto','%s');

 for i=1:length(fname1)
   clear dum_name
   dum_name=char(fname1(i));
  if exist(dum_name)==2 & dum_name(end)=='m'  
   ind_len(ii)=length(char(fname1(i)));
   good_files(ii)=fname1(i);
   ii=ii+1;
  end
 end

end

gf=char(good_files);

% EDIT HERE - filename specific 

   clear date_files

 for i = 1 : length(good_files)
   clear tt 
     tt(i,1:10) = gf(i,(ind_len(i)-10):ind_len(i)-1);                               % the length of date in file name is sonde_+10digits
  date_files(i) = datenum(str2num([tt(i,7:10)]),str2num(tt(i,5:6)),...
                  str2num(tt(i,3:4)),str2num(tt(i,1:2)),0,0 );
 end



%    sorted by time;

[sort_date, ind_sort]=sort(date_files);



% READ in the files found OK:

clear p_all z_all tk_all rh_all wsp_all dd_all


len_rec=1;
p_all(1:length(good_files),1:500)=NaN; z_all(1:length(good_files),1:500)=NaN; tk_all(1:length(good_files),1:500)=NaN;
rh_all(1:length(good_files),1:500)=NaN; wsp_all(1:length(good_files),1:500)=NaN; dd_all(1:length(good_files),1:500)=NaN;

for i=1:length(good_files)

   clear dum1 plev zlev tk rh td wsp dd uvel vvel lon lat dum2 dum3

  sonde_file=char(good_files(ind_sort(i)));                         % get it cronologically

%      p      hgt   tmp    td    rh    r     dd    ff     th    the   thv 
%fmt=['%6.1f %6.0f  %6.1f %6.1f  %6.0f %4.2f %3.0f %3.0f  %4.1f  %4.1f %4.1f\n'];
fmt=['%f %f  %f %f  %f %f %f %f  %f  %f %f '];
[plev zlev tk td rh r dd ff th the thv]=textread(sonde_file,fmt,'headerlines',4);



len_rec=max(len_rec,length(plev));
p_all(i,1:length(plev))=plev; z_all(i,1:length(plev))=zlev; tk_all(i,1:length(plev))=tk; rh_all(i,1:length(plev))=rh; wsp_all(i,1:length(plev))=ff; dd_all(i,1:length(plev))=dd;

end


dim_tim = size(z_all,1);
dim_z   = size(z_all,2);
th_all(1:dim_tim,1:dim_z)=NaN;

tk_all=tk_all+273.16;


%  --  calc theta:

for i=1:dim_tim
 [th_all(i,:)] = calc_theta_T(tk_all(i,:),p_all(i,:),'theta_back');
end

for k = 1:dim_tim
  [ichos] = find( z_all(k,:)<5000 & z_all(k,:)>0 );
  if ~isempty(find(th_all(k,ichos)<0))
   disp(['problem with theta',num2str(k)])
  end
end


%    
%    ---  INTERPOLATE ALL VARIABLES to every 50m:
%

clear tkint thint zint rhint wspint ddint
zint=[100:50:3000];
tkint(1:dim_tim,1:length(zint))  = NaN;
thint(1:dim_tim,1:length(zint))  = NaN;
rhint(1:dim_tim,1:length(zint))  = NaN;
pint(1:dim_tim,1:length(zint))   = NaN;
wspint(1:dim_tim,1:length(zint)) = NaN;
ddint(1:dim_tim,1:length(zint))  = NaN;

for i = [{'p', 'tk', 'th', 'rh', 'wsp', 'dd'}]

 if strcmp('th',char(i))
   not_def=100;
 elseif strcmp('rh',char(i))
   not_def=-0.01;
 elseif strcmp('wsp',char(i))
  not_def=-0.1;
 elseif strcmp('dd',char(i))
  not_def=-0.1;
 elseif strcmp('tk',char(i))
  not_def=-0.1;
 elseif strcmp('p',char(i))
  not_def=-0.1;

 end

 eval(['dum_all=' char(i) '_all;']);
 eval(['dumint=' char(i) 'int;']);



  for j=1:dim_tim

   clear tt

   [tt] = find(~isnan(dum_all(j,:)) & dum_all(j,:)<3000 & dum_all(j,:)>=0 );

     if length(find(~isnan(tt)))>2

      dum_all(j,find(dum_all(j,tt)<not_def))=NaN;

      try
       dumint(j,:)=interp1(z_all(j,tt),dum_all(j,tt),zint,'spline', 'extrap');
      catch
       dumint(j,:)=NaN;
      end

     else

      dumint(j,:)=NaN;
 
     end      

 end                                    % time-loop

 eval([char(i) 'int=dumint;']);
 eval([char(i) '_all=dum_all;']);

end                                     % variable-loop

clear i

%   ---- MISSING data:
%
% if there is only "NaN" for a sonde => remove that time:

 jj=1;
 clear thN tkN rhN wspN ddN dateN

 thN  = thint;
 tkN  = tkint;
 pN   = pint;
 rhN  = rhint;
 wspN = wspint;
 ddN  = ddint;
 dateN= date_files(ind_sort);

 for j=1:dim_tim

  if all(isnan(thint(j,:))) | all(isnan(rhint(j,:))) | all(isnan(wspint(j,:))) | all(isnan(thint(j,:)))
   tkN(j,:) = [];
    pN(j,:) = [];
   thN(j,:) = [];
   rhN(j,:) = [];
  wspN(j,:) = [];
   ddN(j,:) = [];
 dateN(j)   = [];
   end

  end


% Update time_string

dim_tim2 = size(thN,1);
dim_z2   = size(thN,2);

 dz = (zint(2)-zint(1));       % make it dependent on dz
 sl = ceil(70/dz);             % used for standardizing the vertical slak


%
%   ---- NORMALISING data:
%
% subtract th0 from lower PBL from all th-profiles:

clear dth thNN

for i = 1:dim_tim2

 dth(i) = nanmean(thN(i,1:ceil(6*sl)));
 thNN(i,:)    = thN(i,:) - dth(i);
end


%  ---  calc gradients -> dth etc.:

clear dthv drhv dwsp

for i = 1:dim_tim2
 for k = 2:dim_z2
  dthv(i,k) = thNN(i,k)-thNN(i,k-1);
  drhv(i,k) = rhN(i,k)-rhN(i,k-1);
  dwsp(i,k) = wspN(i,k)-wspN(i,k-1);
 end
end

% ---- running mean => smooth the delta-profiles in the vertical:

clear dthN_rm drhN_rm dwsp_rm
for i=1:dim_tim2
 dthN_rm(i,:) = smooth(dthv(i,:)',ceil(sl));
 drhN_rm(i,:) = smooth(drhv(i,:)',ceil(sl));
 dwsp_rm(i,:) = smooth(dwsp(i,:)',ceil(sl));
end

% # # # # # # # # # # # # # # # # # # #  # # # # # #
% ########## END OF DATA PREPARATION SECTION ##########
%  # # # # # # # # # # # # # # # # # # # # # # # # 







eps = 0.622;
rho = 1.26;
L   = 2.5*10^6;
Rv  = 461;
R   = 287;
g   = 9.81;
cp  = 1004;




%  
%  the INVERSION -Algorithm:
%

inv_dpth(1:dim_tim2)     =NaN;
sta_pbl(1:dim_tim2)      =NaN;
sta_abv(1:dim_tim2)      =NaN;
inv_stab(1:dim_tim2)     =NaN;
inv_stab_max(1:dim_tim2) =NaN;
pblh(1:dim_tim2)         =NaN;
u_blw(1:dim_tim2)        =NaN;
u_abv(1:dim_tim2)        =NaN;

stabN(1:dim_tim2,1:dim_z2)      = NaN;
stabmN(1:dim_tim2,1:dim_z2)     = NaN;

zmi=42;

dstab(1:dim_tim2,1:dim_z2)=NaN;
clear stab

for i = 1 : dim_tim2


% --- calc stab (Brunt-Vaisala freq.) for whole profile [ N^2=g*d(lnth)/dz ]:
try

 stab(1:dim_z2) = NaN;

 for j=sl+1:dim_z2-sl
  stab(j)  = sqrt(9.81*(abs(log(nanmean(thN(i,j:j+sl)))-log( nanmean(thN(i,j-sl:j)) ) ))/(zint(sl+1)-zint(1)))*...
         sign(log(nanmean(thN(i,j:j+sl)))-log( nanmean(thN(i,j-sl:j)) )) ;

 end

 stabN(i,1:dim_z2) = stab ;


clear dstab2
dstab2(1:dim_z2-1) = diff(thN(i,:));
dstab(i,1:dim_z2)  = [NaN dstab2];
ddstab             = diff(dstab(i,:));


% find where they pass zero:
clear siv tv dumv                      
 siv  = sign(ddstab);
 tv   = filter([1 1],1,siv);
 dumv = find( tv(1:end)==0 ) ; 

[sort_vdum,sort_idum]=sort(dstab(i,dumv),'descend');    % only maxima

sort_i2 = dumv(sort_idum);                                % get the index referenced to zint
sort_v2 = dstab(i,sort_i2);
max_ind = sort_i2(1);


% if there is an another max that is close in magnitude but lower, use that:

if sort_v2(2)>0.8*sort_v2(1)  & zint(sort_i2(2))<zint(sort_i2(1)) ...
       & zint(sort_i2(1))>1500
 
 max_ind=sort_i2(2);

elseif sort_v2(2)>0.6*sort_v2(1) &  zint(sort_i2(2))<zint(sort_i2(1)) ...
       & zint(sort_i2(1))>1800

 max_ind=sort_i2(2);


end




% ----------  calc the LOWER limit of the inversion (often bounded by positive Rh anomaly):

kk=max_ind;

if drhN_rm(i,max_ind)<1    % use Rh criteria if Rh is low at initial stage

 while dstab(i,kk)>0.2*dstab(i,max_ind) & mean(dstab(i,kk:kk+1))>dstab(i,kk-1) & kk>sl & drhN_rm(i,kk)<1
  kk=kk-1;
 end
 inv_ind_low(i)=kk;

 if drhN_rm(i,kk+1) < 1 & kk>sl
  while dstab(i,kk)>0.2*dstab(i,max_ind) & mean(dstab(i,kk:kk+1))>dstab(i,kk-1) & kk>sl & drhN_rm(i,kk)<1
   kk=kk-1;
  end
  inv_ind_low(i)=kk;
 end

else                      % without considering Rh

 while dstab(i,kk)>0.2*dstab(i,max_ind) & mean(dstab(i,kk:kk+1))>dstab(i,kk-1) & kk>sl 
  kk=kk-1;
 end
 inv_ind_low(i)=kk;

 if drhN_rm(i,kk+1) < 1 & kk>sl
  while dstab(i,kk)>0.2*dstab(i,max_ind) & mean(dstab(i,kk:kk+1))>dstab(i,kk-1) & kk>sl 
   kk=kk-1;
  end
  inv_ind_low(i)=kk;
 end


end


% ------- calc the UPPER inversion limit:

kk=max_ind;

while dstab(i,kk)>0.15*dstab(i,max_ind) & dstab(i,kk)>dstab(i,kk+1) & kk<dim_z2-1 
 kk=kk+1;
end
inv_ind_hg(i)=kk+1;


% if there is 0nly one index that seperates us from OK value => jump!

if dstab(i,kk+1)>0.15*dstab(i,max_ind) & dstab(i,kk)>dstab(i,kk+1) & kk<dim_z2-1             
 kk=kk+1;
 while dstab(i,kk)>0.15*dstab(i,max_ind) & dstab(i,kk)>dstab(i,kk+1) & kk<dim_z2-1 
  kk=kk+1;
 end
 inv_ind_hg(i)=kk;
end

% -----------------------------------------



% if distance between inversion limits are too high (>800m) => narrow the gap

while zint(inv_ind_hg(i))-zint(inv_ind_low(i)) >800 ;

 [min_vudl,min_iud]=min([dstab(i,inv_ind_hg(i)-1) dstab(i,inv_ind_low(i)+1)]);

 if min_iud==2
   inv_ind_low(i) = inv_ind_low(i)+1;
 else
   inv_ind_hg(i)  = inv_ind_hg(i)-1;
 end

end


% ---- calculate the moist stability:

 clear Tk p z Rh es rv Tvp Tk1 area2 areav dTs dTsv theN
  Tk = tkN(i,:);
  p  = pN(i,:)*100;
  z  = zint;
  Rh = rhN(i,:);


  for k = 1: dim_z2

   clear es rv 
      es = 611*exp(17.5*(Tk(k)-273.16)/(Tk(k)-32.19));   % Tk is in kelvin
      rv = eps*es/(p(k)-es); 
%   Tv(k) = Tk(k)*(1+rv/eps)/(1+rv);
  theN(k)= thN(i,k)+rv*L*thN(i,k)/(cp*Tk(k));

  end



stabm(1:dim_z2) = NaN;

 for j = 1+sl:dim_z2-sl
  if rhN(i,j)>90     %  set the level at 90%

   stabm(j) = sqrt(9.81*(abs(log(nanmean(theN(j:j+sl)))-log( nanmean(theN(j-sl:j)) ) ))/(zint(sl+1)-zint(1)))*...
         sign(log(nanmean(theN(j:j+sl)))-log( nanmean(theN(j-sl:j)) )) ;
  else
   stabm(j) = sqrt(9.81*(abs(log(nanmean(thN(i,j:j+sl)))-log( nanmean(thN(i,j-sl:j)) ) ))/(zint(sl+1)-zint(1)))*...
         sign(log(nanmean(thN(i,j:j+sl)))-log( nanmean(thN(i,j-sl:j)) )) ;

  end
 end

  stabmN(i,1:dim_z2) = stabm ;

% save the stability and dept info about the inversion/PBL

 inv_dpth(i)    = zint(inv_ind_hg(i))-zint(inv_ind_low(i));

 sta_inv(i)     = nanmean(stabm(inv_ind_low(i):inv_ind_hg(i)));
 sta_inv_max(i) = nanmax(stabm(inv_ind_low(i):inv_ind_hg(i)));
 sta_pbl(i)     = nanmean(stabm(2:inv_ind_low(i)));
 pblh(i)        = zint(inv_ind_low(i));
 u_blw(i)       = nanmean(wspN(i,2:inv_ind_low(i)));
 sta_abv(i)     = nanmean(stabm(inv_ind_hg(i):min(dim_z2,inv_ind_hg(i)+15)));
 u_abv(i)       = nanmean(wspN(i,inv_ind_hg(i):min(dim_z2,inv_ind_hg(i)+15)));

catch
 display(['Not working: ' num2str(i)] )
end

end





figure(14);histw(pblh(find(~isnan(pblh)))); title(['PBL-height, %Coverage:',num2str(100*length(pblh(find(~isnan(pblh))))/dim_tim2)]);xlabel('[m]');ylabel('cases')
figure(15);histw(sta_inv(find(~isnan(sta_inv)))); title('stability of inversion (based on the mean)');xlabel('[s^{-1}]');ylabel('cases')
figure(17);histw(inv_dpth(find(~isnan(inv_dpth)))); title('Historgram for inversion depth');xlabel('[m]');ylabel('cases')
          ylabel('[s^{-1}]');xlabel('[m]')


% ####################################################################
% Vosper approach: hm/Pblh<=0.5 & Umean/sqrt(g'*pblh) <0.8:
%                 g' = g*dth/th = dz*N^2
%
hm=500;            % height of the mountain
for i=1:dim_tim2

 try
  LeewC(i,1) = hm/pblh(i);
   dth_coef  =  inv_dpth(i)*sta_inv_max(i)^2 ;  
  LeewC(i,2) = mean(wspN(i,1:inv_ind_low(i)))/sqrt(pblh(i)*dth_coef); 
 catch
  LeewC(i,:) = NaN;
 end

end

length(find(LeewC(:,1)<=0.5))
length(find(LeewC(:,2)<0.8))
100*length(find(LeewC(:,2)<0.8 & LeewC(:,1)<=0.5))/dim_tim2
[ind_leew]=find(LeewC(:,2)<0.8 & LeewC(:,1)<=0.5 & nanmean(stabmN(:,1:10),2)<0.005 );
100*length(ind_leew)/dim_tim2

% ############################################################################3

%   Non-hydrostatic wave reflection at the top of boundary layer:
%              4*H^2/pi^2 * ( l_lower^2 - l_upper^2 ) > 1 => lee waves

clear Sc_cond
for i=1:dim_tim2
 Sc_cond(i) = 4*pblh(i)^2/pi^2*(sta_pbl(i)^2/u_blw(i)^2 - sta_abv(i)^2/u_abv(i)^2 );  
end

100*length(find(Sc_cond>1))/dim_tim2





% ########################################

% USED FOR TESTING SOME PLOTS:

for i=1820:2:1830
figure(i)
plot(200*stabN(i,:),zint,'g'); hold on
 plot(drhN_rm(i,:),zint); hold on
  plot(10*dthN_rm(i,:),zint,'r')
  plot(thN(i,:)-273,zint,'.-k')
  plot([1],zint(inv_ind_low(i)),'*')
  plot([2],zint(inv_ind_hg(i)),'d')

  xli=get(gca,'XLim');
  xlim(xli) 
hold off
figure(i+1); plot(dstab(i,:),zint,'.-g')


end







figure(14);print -dpng hist_pblH.png
figure(18);print -dpng stab_vs_invdepth.png
figure(19);print -dpng stabWholepbl.png







close all


