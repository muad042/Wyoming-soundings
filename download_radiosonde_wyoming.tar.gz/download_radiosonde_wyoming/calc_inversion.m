function [SI,IH] = calc_inversion(tc, z);
%% Function to estimate the temperature inversion and the inversion height
%% for a particular sounding. Any level where the temperature starts to
%% increase or remain constant with respect to the level below is
%% considered to be an inversion layer. There might be several of such
%% levels. This function counts the number of such inversions, their
%% strength and the respective height from the ground.

clear dz dt I I1 I2 IH SI count1 count2 dt_inv dz_inv
dz = diff(z);
dt = diff(tc);

[I] = find(sign(dt)==1 | sign(dt)==0);
if (length(I) == 0)
    IH = NaN;
    SI = NaN;
    return;
else 
    [I1] = diff(I);
    [I2] = find(I1~=1);
end         
if (isempty(I2) == 1)    % continuous array => only one inversion
    dt_inv = tc(I(end)+1)-tc(I(1));
    dz_inv = z(I(end)+1)-z(I(1));
    SI = dt_inv/dz_inv; 
    IH = z(I(1)); 
    %'Only one inversion is found, whose strength (dt/dz) is ....'
    %strength_inv
    %If inversion is at the surface (below 100 m), ignore it
    if (IH < 100); SI = NaN; IH = NaN; end 
else
    count1 = 1;
    I2(length(I2)+1) = length(I);
    for i = 1:length(I2)  % no. of inversions = length(I2)+1
       count2 = I2(i);
       dt_inv(i) = tc(I(count2)+1)-tc(I(count1));
       dz_inv(i) = z(I(count2)+1)-z(I(count1));
       SI(i) = dt_inv(i)/dz_inv(i);
       IH(i) = z(I(count1));
       count1 = count2 + 1;
       %If inversion is at the surface (below 50 m), ignore it
       if (IH(i) < 100); SI(i) = NaN; IH(i) = NaN; end     
    end 
    %'There are more than one inversions, with strengths (dt/dz) ....'
    %strength_inv
end 