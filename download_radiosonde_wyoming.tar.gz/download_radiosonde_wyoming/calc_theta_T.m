function [tout] = calc_theta_T(T,p,switch_T);
% This function will calculate theta or T from input
% The switch_T may be: 'T_back' or 'theta_back'
g=9.81; cp=1004; g_cp=g/cp; R=287; cor=10^(-4);

%kdim=length(T);


if strcmp('theta_back',switch_T)
 tout=T.*(1e3./p).^(R/cp);
elseif strcmp('T_back',switch_T)
 tout=T.*(1e3./p).^(-R/cp);
end
